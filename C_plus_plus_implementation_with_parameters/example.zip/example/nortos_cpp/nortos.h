#ifndef _NORTOS_H
#define _NORTOS_H



typedef void(*fP)(void);


/// @brief class for finctional pointers queue with supporting of transfer of parameters




class fQ {
private:
    int first;
    int last;
    int length;
    fP * fQueue;
public:
    fQ(int sizeQ);
    ~fQ();
    int push(fP);
    int pull(void);
};


template <typename T> 
class fQP {  
private:
    int first;
    int last;
    int length;
    void (**FP_Queue)(T);
    T * PARAMS_array;
public:
    fQP(int sizeQ);
    ~fQP();
    int push(void (*pointerQ)(T *), T *);
    int pull(void);
};

template <typename T> fQP<T>::fQP(int sizeQ) { // initialization of Queue
    FP_Queue = new void (*[sizeQ])(T);
    PARAMS_array = new T[sizeQ];
    last = 0;
    first = 0;
    length = sizeQ;
};


template <typename T> fQP<T>::~fQP(){ // initialization of Queue
  delete [] FP_Queue;
};

template <typename T> int fQP<T>::push(void (*pointerQ)(T *), T * parameterQ){ // push element from the queue
  if ((last+1)%length == first)return 1;
  FP_Queue[last] = pointerQ;
  PARAMS_array[FP_last++] = *parameterQ;
  last %= length;
  return 0;
};

template <typename T> int fQP<T>::pull(void){ // pull element from the queue
  void (*pullVar)(T *);
  T * Params;
  if (last == first)return;
  Params = &PARAMS_array[first];
  pullVar = FP_Queue[first++];
  FP_first %= length;
  pullVar(Params);
};



#endif